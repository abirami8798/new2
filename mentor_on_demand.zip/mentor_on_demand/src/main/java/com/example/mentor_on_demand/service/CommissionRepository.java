package com.example.mentor_on_demand.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Commission;



public interface CommissionRepository extends CrudRepository<Commission, Long> {

	Commission save(Commission entity);

}
