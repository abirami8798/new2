package com.example.mentor_on_demand.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Admin;


public interface AdminRepository extends CrudRepository<Admin, Long> {

}
