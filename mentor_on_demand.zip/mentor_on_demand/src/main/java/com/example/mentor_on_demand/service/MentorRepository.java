package com.example.mentor_on_demand.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Mentor;
import com.example.mentor_on_demand.model.MentorCalendar;




public interface MentorRepository extends CrudRepository<Mentor, Long> {

	Optional<Mentor> findById(long id);

	MentorCalendar findByMentorId(long mentorId);

	List<Mentor> findByFirstName(String firstname);

	void deleteByMentorId(int mentorId);

}
