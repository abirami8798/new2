package com.example.mentor_on_demand.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.PaymentHistory;



public interface PaymentHistoryRepository extends CrudRepository<PaymentHistory, Long> {

	PaymentHistory save(PaymentHistory entity);

}
