package com.example.mentor_on_demand.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mentor_on_demand.model.Trainings;
import com.example.mentor_on_demand.service.TrainingRepository;



@CrossOrigin(origins = "http://localhost:4321")
@RestController
@RequestMapping("/api")
public class TrainingController {
	@Autowired
	TrainingRepository trainingRepo;
	
	@PostMapping(value = "/mentor/addtrainings")
	public Trainings postCustomer(@RequestBody Trainings trainings) {

		Trainings trainingInsert = trainingRepo.save(new Trainings(trainings.getSkillId(),trainings.getMentorId(),trainings.getStartTime(),trainings.getEndTime()));
		return trainingInsert;
	
}
}




